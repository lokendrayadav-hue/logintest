import React from 'react'
import Header from './components/Header'
import Footer from './components/Footer';
import AboutBanner from "./Assets/images/about-banner.jpg";
import AboutImg from "./Assets/images/who-we-are-img.jpg";
import { Link } from 'react-router-dom';

const About = () => {
  return (
    <>
      <Header/>
      <section class="inner-banner">
          <img src={AboutBanner} alt="banner-img" className="img-fluid"/>
          <div class="banner-overlay">
              <div class="container">
                  <div class="row">
                      <div class="col-sm-12">
                          <h1 class="page-heading">About Us</h1>
                          <ul class="page-bradcum">
                              <li><Link to="/">Home</Link></li>
                              <li><Link to="about">About Us</Link></li>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <div class="section">
          <div class="container">
              <div class="row">
                  <div class="col-md-6" data-aos="fade-right">
                      <h2 class="men-heading men-heading2">Who We <strong>Are?</strong></h2>
                      <p>We are a team of passionate professionals & subject matter experts who have a very strong desire to add value to industries by helping them achieve operational excellence, perform business processes efficiently and making them a sustainably profitable.</p>
                      <p>We follow a very basic rule that we deliver what we are proficient in and what we have practiced and got benefitted of. Seemingly contrasting, but we have unmatched agility to innovate and evolve new solutions that might be needed to be ahead of the competition.</p>
                      <p>Our strength lies in planning as well as execution till we get desired results.</p>
                  </div>
                  <div class="col-md-6" data-aos="fade-left">
                      <div class="img-thumbnail">
                          <img src={AboutImg} alt="who-we-are-img" class="img-fluid" />
                      </div>                
                  </div>
              </div>
          </div>
      </div>
      <Footer/>
    </>
  )
}

export default About;