import React from 'react';
import ReactDOM from 'react-dom';
import "bootstrap/dist/css/bootstrap.css";
import "./Assets/css/style.css";
import App from './App';
import { AppProvider } from './context/Context';
import {FilterProductContext} from "./context/FilterProductContext"
import { CartProvider } from './context/CartContext';


ReactDOM.render(
  <>
  <AppProvider>
  <FilterProductContext>
    <CartProvider>
      <App/>
    </CartProvider>
  </FilterProductContext>
  </AppProvider>    
  </>,
 document.getElementById("root")
)


