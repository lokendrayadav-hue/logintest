import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './Home';
import About from './About';
import Contact from './Contact';
import SingalProduct from './SingalProduct';
import Products from './Products';

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' Component={Home} />
        <Route path='/about' Component={About} />
        <Route path='/Products' Component={Products} />
        <Route path="/Contact" Component={Contact} />
        <Route path="/product/:sku/:liveInventoryID" Component={SingalProduct} />
      </Routes>
    </BrowserRouter>
  )
}

export default App;