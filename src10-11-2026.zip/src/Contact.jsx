import React from 'react'
import Header from './components/Header'
import Footer from './components/Footer';
import ContactBanner from "./Assets/images/about-banner.jpg";
import { Link } from 'react-router-dom';

const Contact = () => {
  return (
    <>
      <Header/>
      <section className="inner-banner">
          <img src={ContactBanner} alt="banner-img" classNameName="img-fluid"/>
          <div className="banner-overlay">
              <div className="container">
                  <div className="row">
                      <div className="col-sm-12">
                          <h1 className="page-heading">Contact Us</h1>
                          <ul className="page-bradcum">
                              <li><Link to="/">Home</Link></li>
                              <li><Link to="contact">Contact Us</Link></li>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <div className="section home-sec2 contactsec01">
          <div className="container">
            <div className="row">
              <div className="col-md-8">
                <h4>Get in touch with us on</h4>
                <form>
                  <ul className="list-unstyled carrer-form">
                    <li>
                      <label>First Name*</label>
                      <div className="first-name">
                        <select className="sname" name="sname" required>
                            <option value="Mr">Mr</option>
                            <option value="Ms">Ms</option>
                          </select>
                        <input type="text" name="firstname" required />
                      </div>								
                    </li>
                    <li>
                      <label>Last Name</label>
                      <input type="text" name="lastname"/>
                    </li>
                    <li>
                      <label>Email Address*</label>
                      <input type="email" name="email" required/>
                    </li>						
                    <li>
                      <label>Mobile Number*</label>
                      <input type="number" name="mobile" id="mobile_code" required/>
                    </li>
                    <li>
                      <label>Designation*</label>
                      <input type="text" name="designation" required/>
                    </li>
                    <li>
                      <label>Organization*</label>
                      <input type="text" name="organization" required/>
                    </li>							
                    <li className="full-col">
                      <label>Message*</label>
                      <textarea name="message" required></textarea>
                    </li>
                    <li className="full-col">
                      <p className="disclaimer">LEANEXT is committed to protecting your information. However, we would like to contact you and update you about our services on time to time basis. We will never give or sell your information to anyone else.</p>
                                </li>
                                <li className="full-col">
                      <input type="submit" value="Submit" className="sub-form"/>
                    </li>
                  </ul>
                </form>
              </div>
              <div className="col-md-4">
                <div className="impo-res compo-res">
                  <h4>Contact Info</h4>
                  <ul className="list-unstyled foot-con">
                    <li className="add-list">11/825, Indira Nagar,<br/>Lucknow (UP), India, 226016
                    </li>
                    <li className="call-list"><a href="tel:+91 99350 97926">+91 99350 97926</a></li>
                    <li className="mail-list"><a href="mailto:warishi@leanext.in">warishi@leanext.in</a></li>
                  </ul>
                  <h4>Follow Us</h4>
                  <div className="follow-us">
                    <a href="#" target="_balnk"><i className="fa fa-facebook"></i></a>
                    <a href="#" target="_balnk"><i className="fa fa-instagram"></i></a>
                    <a href="#" target="_balnk"><i className="fa fa-linkedin"></i></a>
                    <a href="#" target="_balnk"><i className="fa fa-skype"></i></a>
                    <a href="#" target="_balnk"><i className="fa fa-whatsapp"></i></a>
                  </div>
                </div>
              </div>					
		        </div>
	        </div>
      </div>
      <div className="map-sec">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.4199263771898!2d81.00327331504447!3d26.890164983137158!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3999580bb0a5023f%3A0xb0e06fb7b2b86f7e!2s11%2F825%2C%20Narayan%20Nagar%2C%20Sector%2011%2C%20Indira%20Nagar%2C%20Lucknow%2C%20Uttar%20Pradesh%20226016!5e0!3m2!1sen!2sin!4v1597126563260!5m2!1sen!2sin" style={{height:"347px", width:"100%"}} frameborder="0" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </div>
      <Footer/>
    </>
  )
}

export default Contact;