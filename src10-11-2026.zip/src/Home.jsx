import React from 'react'
import Header from './components/Header'
import Footer from './components/Footer';
import HeroSlider from './components/HeroSlider';
import FeaturedProducts from './components/FeaturedProducts';
const Home = () => {
  return (
    <>
      <Header/>
      <HeroSlider/>
      <FeaturedProducts/>
      <Footer/>
    </>
  )
}

export default Home;