import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Sort from './components/Sort';
import GridView from './components/GridView';
import { useFilterProducts } from './context/FilterProductContext';
import ListView from './components/ListView';
import ProductSidbar from './components/ProductSidbar';

const Products = () => {
  const {Grid_View} = useFilterProducts();

  return (
    <>
    <Header/>
    <div className='container mt-4 mb-4'>
        <div className='row'>
            <div className='col-md-3'>
                <ProductSidbar/>
            </div>
            <div className='col-md-9'>
                <Sort/>
                {Grid_View ? <GridView/> : <ListView/>}
                               
            </div>
        </div>
    </div>
    <Footer/>
    </>
  )
}

export default Products