const FilterProductReducer = (state,action) =>{
    switch(action.type){
        case "Load_Filter_Product":
            let priceArray = action.payload.map((currPrice) => currPrice.price);
            let MaxPriceArray = Math.max(...priceArray);
         return{
            ...state,
            AllProducts:[...action.payload],
            FilterProducts:[...action.payload],
            Filters:{...state.Filters,MaxPrice:MaxPriceArray}           
         }  
         
         case "SET_GRID_VIEW" :
            return{
                ...state,
                Grid_View:true
            }
        
        case "SET_List_VIEW" :
            return{
                ...state,
                Grid_View:false
            }
        case "SORT_FILTER_VALUE" :            
            return{
                ...state,
                SrtValue:action.payload,
                
            }
        case "GET_MAX_PRICE" :
            return{
                MaxPrice:action.payload
            }
        case "SORT_FILTER_PRODUCTS" :
            let newFilterData;
            const {FilterProducts,SrtValue} = state;
            let tempSortData = [...FilterProducts];

            const sortigData = (a, b) =>{
                if(SrtValue === "All"){
                    return newFilterData = tempSortData;
                }
                if(SrtValue === "A-Z"){
                    return a.name.localeCompare(b.name);
                }
                if(SrtValue === "Z-A"){
                    return b.name.localeCompare(a.name);
                }
                if(SrtValue === "Price-Low-To-High"){
                    return a.price-b.price;
                }
                if(SrtValue === "Price-High-To-Low"){
                    return b.price-a.price;
                }
            }

            newFilterData = tempSortData.sort(sortigData);

            return{
                ...state,
                FilterProducts: newFilterData
            }

            case "UPDATE_FILTERS_VALUE" :
            const {name, value} = action.payload;
            return{
                ...state,
                Filters:{
                    ...state.Filters,
                    [name]: value,
                }
            }

            case "FILTER_PRODUCTS" :
            let {AllProducts} = state;
            let tempFilterProduct = [...AllProducts];
            const {text, category, company, colors, price} = state.Filters;

            if(text) {
                tempFilterProduct = tempFilterProduct.filter((currElm)=>{
                    return currElm.name.toLowerCase().includes(text);
                })
            }
            if(category !== "All") {
                tempFilterProduct = tempFilterProduct.filter((currElm)=>{
                    return currElm.category === category;
                })
            }
            if(company !== "All") {
                tempFilterProduct = tempFilterProduct.filter((currElm)=>{
                    return currElm.company === company;
                })
            }
            if(colors !== "All") {
                tempFilterProduct = tempFilterProduct.filter((currElm)=>{
                    return currElm.colors.includes(colors);
                })
            }

            if(price !== 0) {
                tempFilterProduct = tempFilterProduct.filter((currElm)=>{
                    return currElm.price <= price;
                })
            }           

            return{
                ...state,
                FilterProducts: tempFilterProduct
            }

            case "CLEAR_FILTERS" :
            
            return{
                ...state,
                Filters:{
                    text: "",
                    category: "All",
                    company: "All",
                    colors: "All",
                    MaxPrice:state.Filters.MaxPrice,
                    price:state.Filters.price,
                    MinPrice:state.Filters.MinPrice
                }
            }
            
        default:
            return  state;
    }
    
    
}

export default(FilterProductReducer);