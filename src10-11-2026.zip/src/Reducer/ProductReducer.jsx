const ProductReducer = (state, action) =>{
   switch (action.type) { 
      case "SET_LODING":
         return{
            ...state,
            isLoading:true
         }     
      case "SET_API_DATA": 
         return{
            ...state,
            isLoading:false,
            featureProduct:action.payload.filter((currData)=>{
               return currData.featured === true;
            }),
            products:action.payload
         }
      case "SET_SINGAL_PRODUCT" :
         return{
            ...state,
            singalproductData:action.payload
         }
   
      default:
   }
   return  state;
}

export default ProductReducer;