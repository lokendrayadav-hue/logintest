import React, { useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useGlobalContext } from './context/Context';
import Product from './components/Product';
import Header from './components/Header';
import Footer from './components/Footer';
import ProductGallery from './components/ProductGallery';
import FeaturedProducts from './components/FeaturedProducts';
const API = "https://api.pujakaitem.com/api/products"
const SingalProduct = () => {
   const{singalproductData,getSingalProduct} = useGlobalContext();
   const galleryImages = singalproductData.image;
   const productColors = singalproductData.colors;
   const {sku,liveInventoryID} = useParams();

   useEffect(()=>{
    getSingalProduct(sku,liveInventoryID)
   },[sku,liveInventoryID])

   console.log(singalproductData)

  return(
    <>
      <Header/>
      <div className='container mt-4 mb-4'>
        <div className='row'>
          <div className='col-md-5'>
            <div className='imageGallery'>
                <ProductGallery galleryData={galleryImages}/>
            </div>
          </div>
          <div className='col-md-7'>
            <Product prdData={singalproductData} colors={productColors}/>
          </div>
        </div>        
      </div>
      <div className='similar_section'>
        <div className='container text-center'>
            <h2 className='men-heading'>Similar Products</h2>
        </div>
        <FeaturedProducts/>
      </div>
      
      
      <Footer/>
    </>
  ) 
}

export default SingalProduct;