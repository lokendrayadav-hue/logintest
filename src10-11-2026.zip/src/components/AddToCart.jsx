import React from 'react'
import { useCartContext } from '../context/CartContext'

const AddToCart = ({IncreaseAmout,DecreaseAmount,Amount}) => {
  const {AddToProduct} = useCartContext();
  return (
    <div>
        <button className='cardminus' onClick={DecreaseAmount}>-</button>
        <span className='cardnumber'>{Amount}</span>
        <button className='cardplus' onClick={IncreaseAmout}>+</button>
        <button className='form-sub addto-btn' onClick={AddToProduct}>Add To Cart</button>
    </div>
  )
}

export default AddToCart