import React from 'react'
import { useGlobalContext } from '../context/Context';
import ProductOne from './ProductOne';

const FeaturedProducts = () => {
  const {featureProduct, isLoading} = useGlobalContext();
  if(isLoading){
    return <h1>...Loading</h1>
  }
  return (
    <div className='container mt-5 mb-5'>
    <div className='row'>
        {featureProduct.map((currProducts)=>{            
            return(
              <div className='col-md-4'>
                  <ProductOne key={currProducts.id} prdDetails={currProducts}/>
              </div>
            ) 
        })}
    </div>
    </div>
  )
}

export default FeaturedProducts;