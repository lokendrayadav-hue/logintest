import React from 'react'
import Menu from './Menu';
import Logo from "../Assets/images/Leanext-header-logo.png"

const Footer = () => {
  return (
    <footer>
			<div className="top-footer">
				<div className="container">
					<div className="row">
						<div className="col-md-4">
							<div className="footer-logo">
                                <img src={Logo} alt="Leanext-footer-logo" className="img-fluid"/>
							</div>
							<div className="ftr-about">
								<p>We are a team of passionate professionals & subject matter experts who have a very strong desire to add value to industries by helping them achieve operational excellence, perform business processes efficiently and making them a sustainably profitable.</p>
							</div>
						</div>
						<div className="col-md-4 ftr3">
							<h4>Important Links</h4>
							<ul className="list-unstyled cus-link">
								<Menu/>
							</ul>
						</div>						
						<div className="col-md-4">
							<h4>Get in Touch</h4>
							<ul className="list-unstyled foot-con">
								<li className="add-list">A-47, Bloack A, Sector 58<br/>Noida (UP), India, 226016</li>
								<li className="call-list"><a href="tel:+91 9935097926 ">+91 9935097926</a></li>
								<li className="mail-list"><a href="mailto:yaantra@helpdesk.in">yaantra@helpdesk.in</a></li>
							</ul>
							<ul className="list-unstyled social-link">
								<li className="facebook"><a href=""><i className="fa fa-facebook"></i></a></li>
								<li className="twitter"><a href=""><i className="fa fa-twitter"></i></a></li>
								<li className="linkedin"><a href=""><i className="fa fa-linkedin"></i></a></li>
								<li className="instagram"><a href=""><i className="fa fa-instagram"></i></a></li>
								<li className="youtube"><a href=""><i className="fa fa-youtube"></i></a></li>
								<li className="tripadvisor"><a href=""><i className="fa fa-tripadvisor"></i></a></li>
							</ul>
						</div>	
					</div>
					<div className="row">
						<div className="col-md-12">
							<div className="bottom-footer">
								<p>©2022 <a href="index.html">LEANEXT Training & Consulting Pvt. Ltd.</a> All Rights Reserved</p>				
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
  )
}

export default Footer;