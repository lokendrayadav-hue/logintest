import React from 'react'
import { useFilterProducts } from '../context/FilterProductContext';
import ProductOne from "./ProductOne";
import { useGlobalContext } from '../context/Context';

const GridView = () => {
    const {FilterProducts} = useFilterProducts();
    const {isLoading} = useGlobalContext();
    if(isLoading){
      return <h1>...Loading</h1>
    }
  return (
    <div className='row'>                  
        {FilterProducts.map((currProducts)=>{            
            return(
            <div className='col-md-4' style={{marginBottom:"30px"}}>
                <ProductOne margin="30px" key={currProducts.liveInventoryID} prdDetails={currProducts}/>
            </div>
            ) 
        })}
    </div>
  )
}

export default GridView