import React from 'react'
import { Link } from 'react-router-dom'
import Logo from "../Assets/images/Leanext-header-logo.png";
import Menu from './Menu';

const Header = () => {
  return (
    <header className="align-header">
			{/* <div className="top-header">
				<div className="container">
					<div className="row">
						<div className="col-sm-6">
							<ul className="list-unstyled top-left">
								<li className="call-list"><a href="tel:+91 9935097926">+91 9935097926</a></li>
								<li className="mail-list"><a href="mailto:warishi@leanext.in">warishi@leanext.in</a></li>
							</ul>
						</div>
						<div className="col-sm-6 social-right">
							<ul className="list-unstyled top-right">
								<li><a href="#" target="_balnk"><i className="fa fa-facebook"></i></a></li>
								<li><a href="#" target="_balnk"><i className="fa fa-instagram"></i></a></li>
								<li><a href="#" target="_balnk"><i className="fa fa-linkedin"></i></a></li>
								<li><a href="#" target="_balnk"><i className="fa fa-skype"></i></a></li>
								<li><a href="#" target="_balnk"><i className="fa fa-whatsapp"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div> */}
			<div className="mid-header">
				<div className="container">
					<div className="row">
						<div className="col-lg-3 col-9">
							<div className="logo">
                                <Link to="/"><img src={Logo} alt="Leanext-header-logo" className="img-fluid"/></Link>
							</div>
						</div>
						<div className="col-lg-9 col-3">
							<div className="toggler-btn">
								<button className="menu-trigger">
								      <span></span>
								      <span></span>
								      <span></span>
							    </button>
						    </div>
							<div className="menu-sec">
								<ul className="list-unstyled header-menu">
									<Menu/>
								</ul>								
							</div>						
						</div>
					</div>
				</div>
			</div>			
		</header>
  )
}

export default Header;