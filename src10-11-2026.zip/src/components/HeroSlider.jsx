import React from 'react'
import Carousel from 'react-bootstrap/Carousel';
import Banner1 from "../Assets/images/banner1.jpg";
import Banner2 from "../Assets/images/banner2.jpg";
const HeroSlider = () => {
  return (
    <section>
      <Carousel>
      <Carousel.Item>
        <img src={Banner1} alt="banner1"/>
        <div class="slider-content">
	      	<div class="container">
	      		<h2 data-animation="animated zoomIn">For Advanced Learners, <strong>Practitioners & Consultants</strong></h2>
	      	    <p data-animation="animated slideInUp">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
	      	</div>	      	
	      </div>
      </Carousel.Item>
      <Carousel.Item>
      <img src={Banner2} alt="banner1"/>
      <div class="slider-content">
	      	<div class="container">
	      		<h2 data-animation="animated zoomIn">For Advanced Learners, <strong>Practitioners & Consultants</strong></h2>
	      	    <p data-animation="animated slideInUp">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
	      	</div>	      	
	      </div>
      </Carousel.Item>
    </Carousel>
    </section>
  )
}

export default HeroSlider;