import React from 'react'
import { useFilterProducts } from '../context/FilterProductContext';
import { Link } from 'react-router-dom';
import { useGlobalContext } from '../context/Context';

const ListView = () => {
    const {FilterProducts} = useFilterProducts();
    const {isLoading} = useGlobalContext();
    if(isLoading){
      return <h1>...Loading</h1>
    }
  return (
    <div className='row'>                  
        {FilterProducts.map((currProducts)=>{ 
            const {pid, modelName, productImage, sku, mrp, wholeSaleCost} = currProducts; 
            const MRP_Price = Math.round(mrp);
            const Sale_Price = Math.round(wholeSaleCost);          
            return(
                <div className='col-md-12' style={{marginBottom:"30px"}}>
                    <div className='Listbox border p-2 '>
                        <div className='row'>
                            <div className='col-md-3'>
                                <div className='productImg'>
                                    <Link to={`/singleproduct/${sku}${pid}`}>
                                        <img src={productImage} alt='prd-img' className='img-fluid' />
                                    </Link>
                                </div>
                            </div>
                            <div className='col-md-9'>
                                <div className='productcontent'>
                                    <h4>{modelName}</h4>
                                    <p><strong>₹ {Sale_Price}</strong><span className='mrp-price'>₹ {MRP_Price}</span></p>
                                    <p><Link className='form-sub' to={`/singleproduct/${sku}${pid}`}>Read More</Link></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            ) 
        })}
    </div>
  )
}

export default ListView