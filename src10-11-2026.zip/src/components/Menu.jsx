import React from 'react'
import { Link } from 'react-router-dom'

const Menu = () => {
  return (
    <>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/about">About Us</Link></li>
        <li><Link to="/products">Products</Link></li>
        <li><Link to="/contact">Contact Us</Link></li>
    </>        
  )
}

export default Menu;