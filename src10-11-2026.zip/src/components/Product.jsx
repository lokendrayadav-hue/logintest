import React, { useState } from 'react'
import AddToCart from "./AddToCart";


const Product = ({prdData, colors}) => {
    const [cardAmount,setCardAmount] = useState(1);
    const {name,stock, description,price,id,company} = prdData;
    const amount = price / 100;

  const DecreaseCard = () =>{
    setCardAmount(
      cardAmount > 1 ? cardAmount-1 : 1
    )
  }
  const IncreaseCard = () =>{
    setCardAmount(
      cardAmount < stock ? cardAmount+1 : stock
    )
  }
  return (
    <div>
        <h1>{name}</h1>
        <p>{`MRP ${amount}`}</p>
        <p>{description}</p>
        <p>Available : <strong>{stock > 0 ? "In Stock" : "Out of Stock"}</strong></p>
        {
          stock > 0 ? 
          <div>
            <p>ID : <strong>{id}</strong></p>
            <p>Brand : <strong>{company}</strong></p>
            <hr/>
            <p>Color : {colors.map((currColor) => <button className='colorbtn' style={{background:currColor}}></button>)} </p>
            <AddToCart IncreaseAmout={IncreaseCard} DecreaseAmount={DecreaseCard} Amount={cardAmount}/>
          </div>
           : ""
        }
        
    </div>
  )
}

export default Product;