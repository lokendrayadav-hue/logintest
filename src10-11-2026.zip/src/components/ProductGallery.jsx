import React, { useState } from 'react'

const ProductGallery = ({galleryData = [{url:""}]}) => {  
    const [images, setImages] = useState(0);
    return (
      <div className='row'>
        <div className='col-3'>        
            {galleryData.map((galleryimages,index) =>{
                
                return(                
                    <img key={index} onClick={()=> setImages(index)} src={galleryimages.url} alt={galleryimages.filename} className='mb-1 img-fluid'/>
                    
                )
            })}
        </div>
        <div className='col-9'>
             <img src={galleryData[images].url} alt={galleryData[images].filename} className='img-fluid'/>
        </div>
      </div>
    )
}

export default ProductGallery