import React from 'react'
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const ProductOne = ({prdDetails}) => {
    const navigate = useNavigate();

    const handleViewProduct = (sku, liveInventoryID) => {
        navigate(`/product/${sku}/${liveInventoryID}`);
    };

    const {liveInventoryID, modelName, productImage, sku, mrp, wholeSaleCost} = prdDetails;
    const MRP_Price = Math.round(mrp);
    const Sale_Price = Math.round(wholeSaleCost);
    return(
        <div className='card'>
            <img src={productImage} alt='feature-img'/>
            <div className='p-2'>
            <h4 onClick={() => handleViewProduct(sku, liveInventoryID)}>{modelName}</h4>
            <p><strong>₹ {Sale_Price}</strong><span className='mrp-price'>₹ {MRP_Price}</span></p>
            </div>                        
        </div>
    )
}

export default ProductOne;