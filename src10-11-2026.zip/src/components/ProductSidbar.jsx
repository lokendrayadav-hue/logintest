import React from 'react'
import { useFilterProducts } from '../context/FilterProductContext';
import { TiTick } from "react-icons/ti";

const ProductSidbar = () => {
  const {Filters:{text, category, company, colors, price, MaxPrice, MinPrice}, updateFilterValue, AllProducts, ClearFilters} = useFilterProducts();
  const UniqueFun = (Data, Property) =>{
    let newVal = Data.map((currElms) => currElms[Property]);

    if(Property === "colors"){
      let abc = newVal.flat();
      return newVal = ["All", ...new Set(abc)];
    }
    if(Property === "price"){
      return newVal = [...new Set(newVal)];
    }
    return newVal = ["All", ...new Set(newVal)];
  }

  let getcatData = UniqueFun(AllProducts,"category");
  let getcompanyData = UniqueFun(AllProducts,"company");
  let getcolorsData = UniqueFun(AllProducts,"colors");
  
  return (
    <div>
      <form onSubmit={(event)=> event.preventDefault }>
        <input type='text' name='text' value={text} onChange={updateFilterValue} placeholder='Search Here' />
      </form>
      <div className='category-list mt-2'>
          <h4>Category</h4>
          <ul className='list-unstyled'>
            {
              getcatData.map((categoryList, index)=>{
                return <li><button className='catbtn' type='button' key={index} name='category' value={categoryList} onClick={updateFilterValue}>{categoryList}</button></li>
              })
            }
              
          </ul>
      </div>
      <div className='mt-2'>
        <h4>Brand</h4>
          <select type='select' name='company' onChange={updateFilterValue}>
            {getcompanyData.map((companyList)=>{
              return <option value={companyList}>{companyList}</option>
            })}          
          </select>
      </div>
      <div className='mt-2'>
        <h4>colors</h4>
            {
              getcolorsData.map((colorsList,index) => {
                  if (colorsList === "All"){
                  return <button className='catbtn' type='button' key={index} name='colors' value={colorsList} onClick={updateFilterValue} style={{background:colorsList}}>All</button>
                  }
                  return <button className={colors === colorsList ? "catbtn color-btn active" : "catbtn color-btn"} type='button' key={index} name='colors' value={colorsList} onClick={updateFilterValue} style={{background:colorsList}}>{colors === colorsList ? <TiTick /> : ""}</button>
              })
            }
      </div>
      <div className='mt-2'>
        <h4>Price</h4>
        <p>RS {price}</p>
        <input type="range" name="price" min={MinPrice} value={price} max={MaxPrice} step="1000"  onChange={updateFilterValue} />
      </div>
      <div className='mt-2'>
        <button className='btn' onClick={ClearFilters}>Clear Filters</button>
      </div>
    </div>    
  )
}

export default ProductSidbar;