import React from 'react';
import { IoGridOutline } from "react-icons/io5";
import { CiBoxList } from "react-icons/ci";
import { useFilterProducts } from '../context/FilterProductContext';

const Sort = () => {
    const {setGridView, setListView,Grid_View, AllProducts, sortChange} = useFilterProducts();
  return (
    <div className='border p-2 mb-4 bg-light'>
        <div className='row'>
            <div className='col-md-4'>
                <button onClick={setGridView} className={Grid_View ? "sort-btn active" : "sort-btn"}><IoGridOutline /></button>
                <button onClick={setListView} className={!Grid_View ? "sort-btn active" : "sort-btn"}><CiBoxList /></button>
            </div>
            <div className='col-md-4'>
                <div>Avlaible Products <strong>{AllProducts.length}</strong></div>
            </div>
            <div className='col-md-4 text-end'>
                <form>
                    <select name="sord" id='sortdata' onChange={sortChange}>
                        <option value="All">All</option>
                        <option value="Price-High-To-Low">Price High To Low</option>
                        <option value="Price-Low-To-High">Price Low To High</option>
                        <option value="A-Z">A-Z</option>
                        <option value="Z-A">Z-A</option>
                    </select>
                </form>
            </div>
        </div>
    </div>
  )
}

export default Sort;