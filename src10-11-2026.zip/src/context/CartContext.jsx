import { createContext, useContext, useReducer } from "react";
import reducer from "../Reducer/CartReducer"

const CartContext = createContext();


const CartProvider = ({children}) =>{

    const initialState = {

    }
    

    const [state, dispatch] = useReducer(reducer, initialState)

    const AddToProduct = () =>{
        dispatch({type:"ADD_TO_PRODUCT"});
    }
    return(
        <CartContext.Provider value={{...state, AddToProduct}}>
            {children}
        </CartContext.Provider>
    )
}

const useCartContext = () =>{
    return useContext(CartContext)
}

export {CartProvider,useCartContext};