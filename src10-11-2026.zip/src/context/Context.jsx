import axios from "axios";
import { createContext, useContext, useEffect, useReducer } from "react";
import reducer from "../Reducer/ProductReducer";

const AppContext = createContext();
const API = "https://admin.casaabuelagoa.com/api";

const AppProvider = ({children}) =>{

    const initialState = {
        isLoading:false,
        products: [],
        featureProduct:[],
        singalproductData:[]
    }

    const [state, dispatch] = useReducer(reducer, initialState);   

    const getProducts = async (url) =>{
        dispatch({type:"SET_LODING"})
        try {
            const res = await axios.get(`${url}/LiveInventoryDetail/GetAll`);
            const products = await res.data;
            
            dispatch({
                type:"SET_API_DATA",
                payload: products  
            });
        } catch (error) {
         
        }
    }
    const getSingalProduct = async (sku, liveInventoryID) =>{
        const Payload = {
            sku:sku,
            productSpecsId:liveInventoryID                        
        }
        console.log(Payload)
        dispatch({type:"SET_LODING"})
        try {
            const res = await axios.get(`${API}/LiveInventoryDetail/GetProductDetailPage`,Payload);
            const singalproduct = await res.data;
            console.log(res)
            dispatch({
                type:"SET_SINGAL_PRODUCT",
                payload:singalproduct,  
            });
        } catch (error) {
         console.log(error)
        }
            
    }
    useEffect(()=>{
        // getProducts(`${API}?id=${state.id}`);
        getProducts(API);
    }, [2])
    return(
        <AppContext.Provider value={{...state, getSingalProduct}}>
            {children}
        </AppContext.Provider>
    )
}

const useGlobalContext = () =>{
    return useContext(AppContext)
}

export {AppProvider,useGlobalContext};