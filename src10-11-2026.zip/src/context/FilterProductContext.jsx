import { createContext, useContext, useEffect, useReducer } from "react";
import reducer from "../Reducer/FilterProductReducer";
import { useGlobalContext } from "./Context";


const FilterProduct = createContext();

const initialState = {
    FilterProducts:[],
    AllProducts:[],
    Grid_View:true,
    SrtValue:"All",
    Filters:{
        text: "",
        category: "All",
        company: "All",
        colors: "All",
        MaxPrice:0,
        price:0,
        MinPrice:0
        
    }
}

const FilterProductContext = ({children}) =>{
    const {products} = useGlobalContext();

    const [state, dispatch] = useReducer(reducer, initialState);

const setGridView = () =>{
    dispatch({
        type:"SET_GRID_VIEW"
    })
}

const setListView = () =>{
    dispatch({
        type:"SET_List_VIEW"
    })
}

const sortChange = (event) =>{
    let sortValue = event.target.value;

    dispatch({
        type:"SORT_FILTER_VALUE",
        payload : sortValue
    })

}

const updateFilterValue = (event) =>{
    let name = event.target.name;
    let value = event.target.value;
    return dispatch({type: "UPDATE_FILTERS_VALUE", payload: {name, value} });
}


const ClearFilters = () =>{
    dispatch({type:"CLEAR_FILTERS"})
}

useEffect(()=>{
    
    dispatch({
        type:"SORT_FILTER_PRODUCTS",
        payload:products, 
    });
},[state.SrtValue])

useEffect(()=>{
    dispatch({
        type:"SEARCH_PRODUCT_FILTER"
    })

    dispatch({
        type:"Load_Filter_Product",
        payload:products, 
    });

    dispatch({type:"FILTER_PRODUCTS"})
    
},[products])

    return(
        <FilterProduct.Provider value={{ ...state, setGridView, setListView, sortChange, updateFilterValue,ClearFilters}} >
            {children}
        </FilterProduct.Provider>
    )
}

const useFilterProducts = () =>{
    return useContext(FilterProduct);
}

export {FilterProductContext,useFilterProducts}