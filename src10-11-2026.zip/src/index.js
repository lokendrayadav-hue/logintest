import React from 'react';
import ReactDOM from 'react-dom/client';
import "bootstrap/dist/css/bootstrap.css";
import "./Assets/css/style.css";
import App from './App';
import { AppProvider } from './context/Context';
import {FilterProductContext} from "./context/FilterProductContext"
import { CartProvider } from './context/CartContext';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <AppProvider>
  <FilterProductContext>
    <CartProvider>
      <App/>
    </CartProvider>
  </FilterProductContext>
  </AppProvider> 
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
